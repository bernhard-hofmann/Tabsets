var myApp = angular.module('Tabsets', []);
